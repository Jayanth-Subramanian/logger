package logger.date;

import java.io.IOException;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class LoggerSample {

	  static Logger log = Logger.getLogger(LoggerSample.class.getName());  
     
   public static void main(String[] args)throws IOException, SQLException{  
      for (int i=0; i<10000; i++) {
    	  log.info("Hello this is an info message");  
      }
   }  
}
